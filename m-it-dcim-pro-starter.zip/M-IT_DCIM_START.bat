@echo off
title M-IT DCIM Enterprise - Docker Control Center
color 0b

echo =======================================================
echo           M-IT DCIM ENTERPRISE - DOCKER NATIVE
echo =======================================================
echo.

:: 1. Prüfen ob Docker Desktop läuft
:start_check
docker info >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Docker Desktop ist nicht gestartet!
    echo Bitte starte Docker Desktop und druecke eine Taste.
    pause >nul
    goto start_check
)

echo [SYSTEM] Docker Engine erkannt.
echo [SYSTEM] Starte Container-Infrastruktur...
echo.

:: 2. Altreste entfernen und System starten
echo [CLEAN] Bereinige alte Instanzen...
docker-compose down >nul 2>&1

echo [BUILD] Starte Applikation und KI-Download...
docker-compose up --build -d

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [FATAL] Start fehlgeschlagen. Pruefe Docker-Logs.
    pause
    exit
)

echo.
echo =======================================================
echo ✅ SYSTEM-START EINGELEITET!
echo.
echo Der KI-Download (Modell llama3) läuft jetzt im Hintergrund.
echo Das Dashboard ist in Kürze erreichbar.
echo.
echo URL:      http://127.0.0.1:5000
echo =======================================================
echo.
echo Druecke eine Taste, um das Dashboard im Browser zu oeffnen...
pause >nul
start http://127.0.0.1:5000
exit